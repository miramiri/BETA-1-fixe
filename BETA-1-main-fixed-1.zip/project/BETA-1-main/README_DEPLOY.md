# Deploy to Render (Web Service)

This project runs a Telegram userbot (Telethon) **and** a tiny Flask server for Render's health check.

## What I fixed
- `help.py`: fixed broken f-strings and escaped newlines that caused a SyntaxError.
- `selfi.py`: Flask now binds to `PORT` (required on Render) and shows a clear error if `confing.json` is missing.

## One-time setup
1. Commit/push this repo to GitHub **without** your `.session` files or `confing.json` (they contain secrets).
2. On Render:
   - **New > Web Service** and connect your repo.
   - Environment: `Python`
   - Build command: `pip install -r requirements.txt`
   - Start command: `python selfi.py`
   - Add a **Disk** (1 GB is fine) mounted to the service path so Telethon `.session` files persist across restarts.

   If using `render.yaml`, choose **Blueprint** and Render will auto-create the service and disk.

## Secrets (RECOMMENDED)
Instead of `confing.json`, set env vars in Render and adapt code to read them, e.g.:
```python
import os
API_ID = int(os.environ["API_ID"])
API_HASH = os.environ["API_HASH"]
```
and add `API_ID` / `API_HASH` in Render's **Environment** tab. For `sell.py` add `OPENAI_API_KEY` if you use OpenAI features.

## First run
On first deploy, Telethon will need to sign in and create `.session` files. Since this is a user account, complete login the first time (code/password). With Render logs open, follow the prompts.

## Health check
Render calls `/` on the Flask server. You should see a simple message. If the port is wrong, the service will fail—now it's auto-picked from `PORT`.

## Notes
- Keep `.session` files and `groups.json` on the attached disk so state persists.
- Consider migrating all hardcoded tokens/secrets out of the repo.
- If you want a **Background Worker** instead of Web Service, remove Flask and create a `worker` service in `render.yaml`.